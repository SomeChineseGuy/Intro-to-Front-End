var persons = [
  {"name":"Nevada",
  "city":"Vancouver"},
 {"name":"Dylan",
  "city":"Calgary"},
 {"name":"Ivy",
  "city":"Vancouver"},
  {"name":"Mohammed",
  "city":"Toronto"},
  {"name":"Alvin",
  "city":"Mexico"},
  {"name":"Mu",
  "city":"New York"}
];

$(document).ready(function(){
  // Start here!
});
