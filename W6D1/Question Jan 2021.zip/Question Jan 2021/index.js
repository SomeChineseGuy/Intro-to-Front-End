// This is our fake data
var persons = [
  {"name":"Ximena",
  "city":"New York"},
  {"name":"Alvin",
  "city":"Vancouver"},
 {"name":"Scotty",
  "city":"Calgary"},
  {"name":"Anita",
  "city":"Toronto"},
  {"name":"Dan",
  "city":"Canada"},
  {"name":"Bri",
  "city":"Mexico"}
];

$(document).ready(function(){
  // Start here!
});
