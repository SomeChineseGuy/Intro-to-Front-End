var persons = [
  {"name":"Belkis",
  "city":"New York"},
  {"name":"Shawn",
  "city":"Vancouver"},
 {"name":"Nestor",
  "city":"Calgary"},
  {"name":"Suzie",
  "city":"Toronto"},
  {"name":"Alvin",
  "city":"Canada"}
];

$(document).ready(function(){
  // Start here!
});
