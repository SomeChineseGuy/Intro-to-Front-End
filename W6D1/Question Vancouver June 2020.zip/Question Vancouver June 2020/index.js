var persons = [
  {"name":"Colin",
  "city":"Surrey"},
 {"name":"Andrew",
  "city":"Calgary"},
 {"name":"Cameron",
  "city":"Vancouver"},
  {"name":"Emily",
  "city":"Toronto"},
  {"name":"Eric",
  "city":"Mexico"},
  {"name":"Jason",
  "city":"New York"},
  {"name":"Kaden",
  "city":"Spain"},
  {"name":"Kaylyn",
  "city":"Korea"},
  {"name":"Mar",
  "city":"France"},
  {"name":"Samantha",
  "city":"Germany"},
];

$(document).ready(function(){
  // Start here!
});
