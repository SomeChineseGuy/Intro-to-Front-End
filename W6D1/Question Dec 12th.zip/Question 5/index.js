var persons = [
  {"name":"Eric",
  "city":"Vancouver"},
 {"name":"Sheena",
  "city":"Calgary"},
 {"name":"Aaron",
  "city":"Edmonton"},
  {"name":"Connor",
  "city":"Toronto"},
  {"name":"Alvin",
  "city":"Mexico"},
  {"name":"Etebom",
  "city":"New York"},
  {"name":"Jolie",
  "city":"Spain"},
  {"name":"Kevin",
  "city":"Korea"},
  {"name":"Adriana",
  "city":"France"},
  {"name":"Anderi",
  "city":"Hong Kong"},
  {"name":"Alpha",
  "city":"Ireland"},
  {"name":"Jessica",
  "city":"London"},
  {"name":"Saeed",
  "city":"New Zealand"},
];

$(document).ready(function(){
  // Start here!
});
