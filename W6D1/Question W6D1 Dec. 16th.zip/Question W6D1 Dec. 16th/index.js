var persons = [
  {"name":"alvin",
  "city":"Vancouver"},
  {"name":"braeden",
  "city":"Mexico"},
  {"name":"vera",
  "city":"New York"},
  {"name":"chris",
  "city":"Spain"},
  {"name":"jake",
  "city":"Korea"},
  {"name":"jaquelin",
  "city":"Korea"},
];

$(document).ready(function(){
  // Start here!
});
