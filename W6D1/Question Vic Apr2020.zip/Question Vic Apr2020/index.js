var persons = [
  {"name":"Josh",
  "city":"Mathius"},
 {"name":"Maria",
  "city":"Calgary"},
 {"name":"Thain",
  "city":"Vancouver"},
  {"name":"Harkirat",
  "city":"Toronto"},
  {"name":"Alvin",
  "city":"Mexico"},
  {"name":"Gill",
  "city":"New York"},
  {"name":"Kim",
  "city":"Spain"},
  {"name":"Colin",
  "city":"Korea"},
  {"name":"Alona",
  "city":"France"},
];

$(document).ready(function(){
  // Start here!
});
