var persons = [
  {"name":"alvin",
  "city":"Vancouver"},
  {"name":"beatrice",
  "city":"Mexico"},
  {"name":"liam",
  "city":"New York"},
  {"name":"nhi",
  "city":"Spain"},
  {"name":"robert",
  "city":"Korea"},
  {"name":"yin",
  "city":"South Africa"},
  {"name":"yury",
  "city":"London"},
  {"name":"dao",
  "city":"France"},
  {"name":"ting",
  "city":"Russia"},
  {"name":"tram",
  "city":"Toronto"},
  {"name":"nu",
  "city":"Seattle"},
];

$(document).ready(function(){
  // Start here!
});
