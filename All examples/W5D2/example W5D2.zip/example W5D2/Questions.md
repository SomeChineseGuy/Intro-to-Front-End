### First
- Why isn't jQuery working?
Because jQuery was called after Javascript

### Example one
- When I click the "box-one" box I want to change the color to "Teal"
- When I click the "box-two" Box, I want to change the "Pink" Box to Blue
- When I click the "box-three" box I want to "slide up" the other 2 boxes!
- When I click the "box-black" box the page I want all the 2 missing boxes boxes to "slide down"

## Example two
- How do I Stop the page from refreshing/going to another URL when I hit click me!
- When I "Focus" on the input field how do I change the background color?
- When I submit the form I want to "See" the p tag with the class of "hide"
- When I click the "click me!" Set input color back to white

## Bonus!
- When I click the "click me!" button how do I clear the input?

## Example three
- When I hover over the Teal Box I want to add the class "black"

## Bonus!
- When I click orange box I want to reset reset the page
