// Info
var persons = [
  {"name":"Josh",
  "city":"Vancouver"},
 {"name":"Ali",
  "city":"Calgary"},
 {"name":"Janelle",
  "city":"Vancouver"},
  {"name":"Zuge",
  "city":"Toronto"},
  {"name":"Alvin",
  "city":"Mexico"},
  {"name":"Sahand",
  "city":"New York"},
  {"name":"Catherin",
  "city":"Spain"},
  {"name":"Christy",
  "city":"Korea"},
  {"name":"Julie",
  "city":"France"},
  {"name":"Eunice",
  "city":"Hong Kong"},
  {"name":"Justine",
  "city":"Ireland"},
  {"name":"Erick",
  "city":"London"},
];

$(document).ready(function(){
// Write Our code here!
});
