// Info
var persons = [
  {"name":"Alvin",
  "city":"Mexico"},
  {"name":"Jessica",
  "city":"Japan"},
  {"name":"Pablo",
  "city":"Spain"}
];

$(document).ready(function(){
    // Write code here!

});
